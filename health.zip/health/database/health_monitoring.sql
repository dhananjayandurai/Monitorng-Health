-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2021 at 04:09 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `health_monitoring`
--

-- --------------------------------------------------------

--
-- Table structure for table `default_health`
--

CREATE TABLE `default_health` (
  `id` int(11) NOT NULL,
  `type` varchar(1000) NOT NULL,
  `min` varchar(1000) NOT NULL,
  `max` varchar(1000) NOT NULL,
  `impact_max` varchar(1000) NOT NULL,
  `impact_min` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `default_health`
--

INSERT INTO `default_health` (`id`, `type`, `min`, `max`, `impact_max`, `impact_min`) VALUES
(1, 'body_temperature', '97.0', '99.0', 'A body temperature higher than your normal range is a fever.', 'A body temperature lower than your normal range is a Hypothermia.'),
(2, 'blood_pressure', '100', '120', 'If blood pressure is extremely high, there may be certain symptoms: Severe headaches, Chest pain, Difficulty breathing, Irregular heartbeat.', 'Low blood pressure as dangerous if it causes noticeable symptoms are Dizziness or lightheadedness, Dehydration and unusual thirst, Lack of concentration, Blurred vision, Cold, shallow breathing,Depression'),
(3, 'respiration', '12', '20', ' Respiration rates may increase with fever, illness, and other medical conditions.', 'Emotional stress and chronic anxiety can lead to a decrease in respiration rate.'),
(4, 'glucose', '72', '99', 'Hyperglycaemia is the medical term for a high blood sugar glucose level. It\'s a common problem for people with diabetes.', 'A variety of things can trigger an increase in blood sugar level in people with diabetes, including stress ,an illness, such as a cold ,eating too much , such as snacking between meals ,a lack of exercise.'),
(5, 'pulse', '60', '100', 'Tachycardia occur when heart rate is high. Heart-related conditions such as high blood pressure ,Poor blood supply to the heart muscle due to coronary artery disease.', 'Bradycardia is a heart rate that’s too slow. Metabolic problems such as hypothyroidism ,Damage to the heart from heart disease or heart attack'),
(6, 'oxygen_saturation', '95', '100', 'If the oxygen level is too high and unchecked, these radicals can severely damage or kill lung tissue. If left for a prolonged period of time the patient can suffer permanent lung damage.', 'A below-normal blood oxygen level is called hypoxemia. Hypoxemia is often cause for concern. This can lead to complications in body tissue and organs.'),
(7, 'electro_cardiogram', '120', '200', 'An abnormal ECG result may be a sign of high blood pressure ,heart disease like heart attack', 'An abnormal ECG result may be a sign of high blood pressure ,heart disease like heart attack');

-- --------------------------------------------------------

--
-- Table structure for table `health_details`
--

CREATE TABLE `health_details` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `body_temperature` float NOT NULL,
  `blood_presure` int(11) NOT NULL,
  `respiration` int(11) NOT NULL,
  `glucose` int(11) NOT NULL,
  `pulse` int(11) NOT NULL,
  `oxygen_saturation` int(11) NOT NULL,
  `electro_cardiogram` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `health_details`
--

INSERT INTO `health_details` (`id`, `user_id`, `body_temperature`, `blood_presure`, `respiration`, `glucose`, `pulse`, `oxygen_saturation`, `electro_cardiogram`) VALUES
(1, 7, 98.6, 90, 20, 80, 70, 92, 140),
(2, 8, 98.7, 91, 21, 81, 71, 96, 141),
(3, 9, 98.8, 92, 22, 80, 70, 97, 144),
(4, 10, 98.1, 95, 24, 90, 85, 97, 160),
(5, 11, 97.8, 100, 25, 95, 90, 99, 168),
(6, 12, 98.1, 95, 22, 90, 100, 98, 189),
(7, 13, 98.7, 91, 21, 81, 85, 95, 169),
(8, 14, 98.8, 92, 22, 90, 90, 96, 141),
(9, 15, 98.4, 100, 23, 99, 98, 100, 130),
(10, 16, 97.8, 89, 21, 98, 89, 94, 180),
(11, 17, 98.1, 100, 20, 75, 86, 96, 122),
(12, 18, 98.7, 95, 21, 99, 100, 92, 144),
(13, 19, 98.8, 92, 22, 80, 100, 99, 140),
(14, 20, 98.7, 91, 21, 81, 85, 99, 189),
(15, 21, 98.8, 92, 24, 80, 70, 98, 174),
(16, 22, 98.1, 116, 22, 99, 100, 92, 149),
(17, 23, 97.8, 116, 23, 81, 85, 92, 168),
(18, 24, 98.7, 92, 22, 99, 71, 97, 189),
(19, 25, 98.8, 100, 20, 80, 70, 95, 140),
(20, 26, 98.4, 116, 24, 99, 85, 99, 160),
(21, 27, 98.1, 95, 23, 98, 70, 95, 144),
(22, 28, 98.1, 95, 23, 99, 70, 98, 160),
(23, 29, 98.7, 89, 23, 98, 90, 96, 189),
(24, 30, 98.4, 89, 23, 81, 85, 97, 144),
(25, 31, 99, 90, 22, 135, 118, 92, 156),
(26, 32, 97.9, 119, 20, 78, 70, 96, 141),
(27, 33, 99, 116, 21, 90, 71, 96, 160),
(28, 34, 98.4, 100, 23, 90, 90, 95, 189),
(29, 35, 98.4, 91, 25, 95, 100, 98, 144);

-- --------------------------------------------------------

--
-- Table structure for table `normal_health`
--

CREATE TABLE `normal_health` (
  `id` int(11) NOT NULL,
  `body_temperature` varchar(12) NOT NULL,
  `blood_presure` varchar(12) NOT NULL,
  `respiration` varchar(12) NOT NULL,
  `glucose` varchar(12) NOT NULL,
  `pulse` varchar(12) NOT NULL,
  `oxygen_saturation` varchar(12) NOT NULL,
  `electro_cardiogram` varchar(12) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `normal_health`
--

INSERT INTO `normal_health` (`id`, `body_temperature`, `blood_presure`, `respiration`, `glucose`, `pulse`, `oxygen_saturation`, `electro_cardiogram`, `user_id`, `type`) VALUES
(1, '97.0-99.0 ', '100-120', '12-16', '72-99', '60-100', '95-100', '120-200', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `id` int(11) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `email_id` varchar(35) NOT NULL,
  `age` int(12) NOT NULL,
  `password` varchar(16) NOT NULL,
  `created_date` date NOT NULL,
  `is_admin` int(11) NOT NULL,
  `mobile_no` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `user_name`, `email_id`, `age`, `password`, `created_date`, `is_admin`, `mobile_no`) VALUES
(7, 'Ajay', 'ajay@gmail.com', 23, 'ajay23', '0000-00-00', 0, 9876543211),
(8, 'Banu', 'banu@gmail.com', 23, 'banu23', '0000-00-00', 0, 9876543221),
(9, 'Cabir', 'cabir@gmail.com', 24, 'cabir24', '0000-00-00', 0, 9876543213),
(10, 'Dhanu', 'dhanu@gmal.com', 24, 'dhanu24', '0000-00-00', 0, 9876543213),
(11, 'Elakiya', 'elakiya@gmal.com', 24, 'elakiya24', '0000-00-00', 0, 9876543124),
(12, 'Fahim', 'fahim@gmail.com', 25, 'fahim25', '0000-00-00', 0, 9876543215),
(13, 'Gabi', 'gabi@gmail.com', 25, 'gabi25', '0000-00-00', 0, 9876543216),
(14, 'Habin', 'habin@gmail.com', 23, 'habi23', '0000-00-00', 0, 9876543216),
(15, 'Ishu', 'ishu@gmail.com', 24, 'ishu24', '0000-00-00', 0, 9876543217),
(16, 'Jamu', 'jamu@gmail.com', 23, 'jamu23', '0000-00-00', 0, 9876543299),
(17, 'Kamini', 'kamini@gmail.com', 23, 'kamini23', '0000-00-00', 0, 9987654321),
(18, 'Lahir', 'lahir@gmail.com', 24, 'lahir24', '0000-00-00', 0, 9987654322),
(19, 'Mani', 'mani@gmailcom', 23, 'mani23', '0000-00-00', 0, 9887654321),
(20, 'Narun', 'narun@gmail.com', 23, 'narun23', '0000-00-00', 0, 9877654321),
(21, 'Osaka', 'osaka@gmail.com', 24, 'osaka24', '0000-00-00', 0, 9876654321),
(22, 'Pavan', 'pavan@gmail.com', 23, 'pavan23', '0000-00-00', 0, 9875654321),
(23, 'Queen', 'queen@gmail.com', 23, 'queen23', '0000-00-00', 0, 9876543211),
(24, 'Ravi', 'ravi@gmail.com', 23, 'ravi23', '0000-00-00', 0, 9988765432),
(25, 'Sabin', 'sabin@gmail.com', 23, 'sabin23', '0000-00-00', 0, 9876543219),
(26, 'Tami', 'tamil@gmail.com', 23, 'tamil23', '0000-00-00', 0, 9876553211),
(27, 'Uvan', 'uvan@gmail.com', 23, 'uvan23', '0000-00-00', 0, 9877543213),
(28, 'Varun', 'varun@gmail.com', 23, 'varun23', '0000-00-00', 0, 97765432254),
(29, 'Wamo', 'wamo@gmail.com', 23, 'wamu23', '0000-00-00', 0, 9878654326),
(30, 'Xami', 'xami@gmail.com', 23, 'xami23', '0000-00-00', 0, 9875543211),
(31, 'Yalini', 'yalini@gmail.com', 23, 'yalini23', '0000-00-00', 0, 9876627821),
(32, 'Zamir', 'zamir@gmail.com', 23, 'zamir23', '0000-00-00', 0, 9876565432),
(33, 'Zomu', 'zomu@gmail.com', 24, 'zomu24', '0000-00-00', 0, 9876353211),
(34, 'Zenkins', 'zenkins@gmail.com', 23, 'zenkins23', '0000-00-00', 0, 9876567211),
(35, 'Yuvin', 'yuvin@gmail.com', 23, 'yuvin23', '0000-00-00', 0, 9834343211),
(36, 'admin', 'admin@gmail.com', 0, 'admin', '0000-00-00', 1, 0),
(37, 'dhanajayan', 'dhananjayandurai@gmail.com', 0, 'dhanan2000', '0000-00-00', 1, 9842195965);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `default_health`
--
ALTER TABLE `default_health`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `health_details`
--
ALTER TABLE `health_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `normal_health`
--
ALTER TABLE `normal_health`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `default_health`
--
ALTER TABLE `default_health`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `health_details`
--
ALTER TABLE `health_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `normal_health`
--
ALTER TABLE `normal_health`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
